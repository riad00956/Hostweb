import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const bots = pgTable("bots", {
  id: serial("id").primaryKey(),
  token: text("token").notNull().unique(),
  name: text("name").notNull(),
  username: text("username").notNull(),
  status: text("status").notNull().default("stopped"), // running, stopped, error, paused
  messageCount: integer("message_count").notNull().default(0),
  totalUsers: integer("total_users").notNull().default(0),
  uptime: integer("uptime").notNull().default(0), // seconds
  lastActive: timestamp("last_active"),
  errorMessage: text("error_message"),
  responseTime: integer("response_time").default(0), // milliseconds
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  botId: integer("bot_id").references(() => bots.id),
  type: text("type").notNull(), // started, stopped, error, paused, message
  message: text("message").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const logs = pgTable("logs", {
  id: serial("id").primaryKey(),
  botId: integer("bot_id").references(() => bots.id),
  level: text("level").notNull(), // info, warn, error
  message: text("message").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertBotSchema = createInsertSchema(bots).pick({
  token: true,
  name: true,
});

export const insertActivitySchema = createInsertSchema(activities).pick({
  botId: true,
  type: true,
  message: true,
});

export const insertLogSchema = createInsertSchema(logs).pick({
  botId: true,
  level: true,
  message: true,
});

export type InsertBot = z.infer<typeof insertBotSchema>;
export type Bot = typeof bots.$inferSelect;
export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activities.$inferSelect;
export type InsertLog = z.infer<typeof insertLogSchema>;
export type Log = typeof logs.$inferSelect;

export const botTokenSchema = z.string().regex(/^\d+:[A-Za-z0-9_-]{35}$/, "Invalid bot token format");
