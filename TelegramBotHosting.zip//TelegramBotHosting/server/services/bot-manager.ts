import TelegramBot from "node-telegram-bot-api";
import { WebSocket } from "ws";
import { storage } from "../storage";
import type { Bot } from "@shared/schema";

interface BotInstance {
  bot: TelegramBot;
  botData: Bot;
  startTime: Date;
  messageCount: number;
}

class BotManager {
  private instances: Map<number, BotInstance> = new Map();
  private wsClients: Set<WebSocket> = new Set();

  addWSClient(ws: WebSocket) {
    this.wsClients.add(ws);
    ws.on("close", () => {
      this.wsClients.delete(ws);
    });
  }

  broadcast(message: any) {
    const data = JSON.stringify(message);
    this.wsClients.forEach(ws => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(data);
      }
    });
  }

  async validateToken(token: string): Promise<{ valid: boolean; username?: string; name?: string }> {
    try {
      const tempBot = new TelegramBot(token);
      const me = await tempBot.getMe();
      return {
        valid: true,
        username: me.username || `bot_${me.id}`,
        name: me.first_name,
      };
    } catch (error) {
      return { valid: false };
    }
  }

  async startBot(botId: number): Promise<boolean> {
    try {
      const botData = await storage.getBot(botId);
      if (!botData) {
        throw new Error("Bot not found");
      }

      if (this.instances.has(botId)) {
        await this.stopBot(botId);
      }

      const bot = new TelegramBot(botData.token, { polling: true });
      const startTime = new Date();

      // Set up message handlers
      bot.on("message", async (msg) => {
        const instance = this.instances.get(botId);
        if (instance) {
          instance.messageCount++;
          await storage.updateBot(botId, {
            messageCount: botData.messageCount + instance.messageCount,
            lastActive: new Date(),
          });

          await storage.createLog({
            botId,
            level: "info",
            message: `Message received from ${msg.from?.username || "user"}: "${msg.text || "[media]"}"`
          });

          this.broadcast({
            type: "log",
            data: {
              botId,
              level: "info",
              message: `Message received from ${msg.from?.username || "user"}: "${msg.text || "[media]"}"`,
              timestamp: new Date(),
            }
          });

          // Simple echo response for demo
          if (msg.text) {
            bot.sendMessage(msg.chat.id, `Echo: ${msg.text}`);
            await storage.createLog({
              botId,
              level: "info",
              message: `Response sent: "Echo: ${msg.text}"`
            });
          }
        }
      });

      bot.on("polling_error", async (error) => {
        console.error(`Bot ${botId} polling error:`, error);
        await storage.updateBot(botId, {
          status: "error",
          errorMessage: error.message,
        });

        await storage.createLog({
          botId,
          level: "error",
          message: `Polling error: ${error.message}`
        });

        await storage.createActivity({
          botId,
          type: "error",
          message: `Bot encountered polling error: ${error.message}`
        });

        this.broadcast({
          type: "bot_status",
          data: { botId, status: "error", errorMessage: error.message }
        });
      });

      this.instances.set(botId, {
        bot,
        botData,
        startTime,
        messageCount: 0,
      });

      await storage.updateBot(botId, {
        status: "running",
        lastActive: new Date(),
        errorMessage: null,
      });

      await storage.createActivity({
        botId,
        type: "started",
        message: `Bot ${botData.name} started successfully`
      });

      this.broadcast({
        type: "bot_status",
        data: { botId, status: "running" }
      });

      // Start uptime tracking
      this.startUptimeTracking(botId);

      return true;
    } catch (error) {
      console.error(`Failed to start bot ${botId}:`, error);
      await storage.updateBot(botId, {
        status: "error",
        errorMessage: error instanceof Error ? error.message : "Unknown error",
      });

      await storage.createActivity({
        botId,
        type: "error",
        message: `Failed to start bot: ${error instanceof Error ? error.message : "Unknown error"}`
      });

      this.broadcast({
        type: "bot_status",
        data: { 
          botId, 
          status: "error", 
          errorMessage: error instanceof Error ? error.message : "Unknown error" 
        }
      });

      return false;
    }
  }

  async stopBot(botId: number): Promise<boolean> {
    try {
      const instance = this.instances.get(botId);
      if (!instance) {
        return false;
      }

      await instance.bot.stopPolling();
      this.instances.delete(botId);

      await storage.updateBot(botId, {
        status: "stopped",
      });

      await storage.createActivity({
        botId,
        type: "stopped",
        message: `Bot ${instance.botData.name} stopped`
      });

      this.broadcast({
        type: "bot_status",
        data: { botId, status: "stopped" }
      });

      return true;
    } catch (error) {
      console.error(`Failed to stop bot ${botId}:`, error);
      return false;
    }
  }

  async pauseBot(botId: number): Promise<boolean> {
    try {
      const instance = this.instances.get(botId);
      if (!instance) {
        return false;
      }

      await instance.bot.stopPolling();
      this.instances.delete(botId);

      await storage.updateBot(botId, {
        status: "paused",
      });

      await storage.createActivity({
        botId,
        type: "paused",
        message: `Bot ${instance.botData.name} paused by user`
      });

      this.broadcast({
        type: "bot_status",
        data: { botId, status: "paused" }
      });

      return true;
    } catch (error) {
      console.error(`Failed to pause bot ${botId}:`, error);
      return false;
    }
  }

  async restartBot(botId: number): Promise<boolean> {
    await this.stopBot(botId);
    await new Promise(resolve => setTimeout(resolve, 1000)); // Wait 1 second
    return await this.startBot(botId);
  }

  private startUptimeTracking(botId: number) {
    const interval = setInterval(async () => {
      const instance = this.instances.get(botId);
      if (!instance) {
        clearInterval(interval);
        return;
      }

      const uptime = Math.floor((Date.now() - instance.startTime.getTime()) / 1000);
      await storage.updateBot(botId, { uptime });
    }, 30000); // Update every 30 seconds
  }

  getBotStatus(botId: number): string | null {
    const instance = this.instances.get(botId);
    return instance ? "running" : null;
  }

  async getSystemStats() {
    const stats = await storage.getStats();
    return {
      ...stats,
      cpuUsage: Math.floor(Math.random() * 30) + 10, // Mock CPU usage
      memoryUsage: Math.floor(Math.random() * 40) + 50, // Mock memory usage
    };
  }
}

export const botManager = new BotManager();
