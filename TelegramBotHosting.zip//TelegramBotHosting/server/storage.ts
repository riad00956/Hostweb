import { bots, activities, logs, type Bot, type InsertBot, type Activity, type InsertActivity, type Log, type InsertLog } from "@shared/schema";

export interface IStorage {
  // Bot methods
  getBot(id: number): Promise<Bot | undefined>;
  getBotByToken(token: string): Promise<Bot | undefined>;
  getAllBots(): Promise<Bot[]>;
  createBot(bot: InsertBot & { username: string }): Promise<Bot>;
  updateBot(id: number, updates: Partial<Bot>): Promise<Bot | undefined>;
  deleteBot(id: number): Promise<boolean>;

  // Activity methods
  createActivity(activity: InsertActivity): Promise<Activity>;
  getRecentActivities(limit?: number): Promise<Activity[]>;
  getBotActivities(botId: number, limit?: number): Promise<Activity[]>;

  // Log methods
  createLog(log: InsertLog): Promise<Log>;
  getRecentLogs(limit?: number): Promise<Log[]>;
  getBotLogs(botId: number, limit?: number): Promise<Log[]>;

  // Stats methods
  getStats(): Promise<{
    activeBots: number;
    messagesToday: number;
    avgUptime: number;
    totalErrors: number;
  }>;
}

export class MemStorage implements IStorage {
  private bots: Map<number, Bot>;
  private activities: Map<number, Activity>;
  private logs: Map<number, Log>;
  private currentBotId: number;
  private currentActivityId: number;
  private currentLogId: number;

  constructor() {
    this.bots = new Map();
    this.activities = new Map();
    this.logs = new Map();
    this.currentBotId = 1;
    this.currentActivityId = 1;
    this.currentLogId = 1;
  }

  async getBot(id: number): Promise<Bot | undefined> {
    return this.bots.get(id);
  }

  async getBotByToken(token: string): Promise<Bot | undefined> {
    return Array.from(this.bots.values()).find(bot => bot.token === token);
  }

  async getAllBots(): Promise<Bot[]> {
    return Array.from(this.bots.values());
  }

  async createBot(insertBot: InsertBot & { username: string }): Promise<Bot> {
    const id = this.currentBotId++;
    const bot: Bot = {
      ...insertBot,
      id,
      status: "stopped",
      messageCount: 0,
      totalUsers: 0,
      uptime: 0,
      lastActive: null,
      errorMessage: null,
      responseTime: null,
      createdAt: new Date(),
    };
    this.bots.set(id, bot);
    return bot;
  }

  async updateBot(id: number, updates: Partial<Bot>): Promise<Bot | undefined> {
    const bot = this.bots.get(id);
    if (!bot) return undefined;
    
    const updatedBot = { ...bot, ...updates };
    this.bots.set(id, updatedBot);
    return updatedBot;
  }

  async deleteBot(id: number): Promise<boolean> {
    return this.bots.delete(id);
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = this.currentActivityId++;
    const activity: Activity = {
      ...insertActivity,
      id,
      timestamp: new Date(),
    };
    this.activities.set(id, activity);
    return activity;
  }

  async getRecentActivities(limit: number = 50): Promise<Activity[]> {
    const activities = Array.from(this.activities.values())
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
    return activities;
  }

  async getBotActivities(botId: number, limit: number = 50): Promise<Activity[]> {
    const activities = Array.from(this.activities.values())
      .filter(activity => activity.botId === botId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
    return activities;
  }

  async createLog(insertLog: InsertLog): Promise<Log> {
    const id = this.currentLogId++;
    const log: Log = {
      ...insertLog,
      id,
      timestamp: new Date(),
    };
    this.logs.set(id, log);
    return log;
  }

  async getRecentLogs(limit: number = 100): Promise<Log[]> {
    const logs = Array.from(this.logs.values())
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
    return logs;
  }

  async getBotLogs(botId: number, limit: number = 100): Promise<Log[]> {
    const logs = Array.from(this.logs.values())
      .filter(log => log.botId === botId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
    return logs;
  }

  async getStats() {
    const allBots = Array.from(this.bots.values());
    const activeBots = allBots.filter(bot => bot.status === "running").length;
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const todayLogs = Array.from(this.logs.values())
      .filter(log => log.timestamp >= today && log.message.includes("Message received"));
    const messagesToday = todayLogs.length;
    
    const totalUptime = allBots.reduce((sum, bot) => sum + bot.uptime, 0);
    const avgUptime = allBots.length > 0 ? totalUptime / allBots.length : 0;
    
    const errorLogs = Array.from(this.logs.values())
      .filter(log => log.level === "error" && log.timestamp >= today);
    const totalErrors = errorLogs.length;

    return {
      activeBots,
      messagesToday,
      avgUptime: Math.round((avgUptime / 86400) * 1000) / 10, // Convert to percentage
      totalErrors,
    };
  }
}

export const storage = new MemStorage();
