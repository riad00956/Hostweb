import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { botManager } from "./services/bot-manager";
import { insertBotSchema, botTokenSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws: WebSocket) => {
    console.log('WebSocket client connected');
    botManager.addWSClient(ws);

    ws.on('close', () => {
      console.log('WebSocket client disconnected');
    });
  });

  // Get all bots
  app.get("/api/bots", async (req, res) => {
    try {
      const bots = await storage.getAllBots();
      res.json(bots);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bots" });
    }
  });

  // Get single bot
  app.get("/api/bots/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const bot = await storage.getBot(id);
      if (!bot) {
        return res.status(404).json({ message: "Bot not found" });
      }
      res.json(bot);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bot" });
    }
  });

  // Create new bot
  app.post("/api/bots", async (req, res) => {
    try {
      const data = insertBotSchema.parse(req.body);
      
      // Validate token format
      botTokenSchema.parse(data.token);

      // Check if token already exists
      const existingBot = await storage.getBotByToken(data.token);
      if (existingBot) {
        return res.status(400).json({ message: "Bot token already exists" });
      }

      // Validate token with Telegram
      const validation = await botManager.validateToken(data.token);
      if (!validation.valid) {
        return res.status(400).json({ message: "Invalid bot token" });
      }

      const bot = await storage.createBot({
        ...data,
        username: validation.username!,
      });

      await storage.createActivity({
        botId: bot.id,
        type: "created",
        message: `New bot ${bot.name} added successfully`
      });

      res.status(201).json(bot);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create bot" });
    }
  });

  // Start bot
  app.post("/api/bots/:id/start", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await botManager.startBot(id);
      if (!success) {
        return res.status(400).json({ message: "Failed to start bot" });
      }
      res.json({ message: "Bot started successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to start bot" });
    }
  });

  // Stop bot
  app.post("/api/bots/:id/stop", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await botManager.stopBot(id);
      if (!success) {
        return res.status(400).json({ message: "Failed to stop bot" });
      }
      res.json({ message: "Bot stopped successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to stop bot" });
    }
  });

  // Pause bot
  app.post("/api/bots/:id/pause", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await botManager.pauseBot(id);
      if (!success) {
        return res.status(400).json({ message: "Failed to pause bot" });
      }
      res.json({ message: "Bot paused successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to pause bot" });
    }
  });

  // Restart bot
  app.post("/api/bots/:id/restart", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await botManager.restartBot(id);
      if (!success) {
        return res.status(400).json({ message: "Failed to restart bot" });
      }
      res.json({ message: "Bot restarted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to restart bot" });
    }
  });

  // Delete bot
  app.delete("/api/bots/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      // Stop bot first if running
      await botManager.stopBot(id);
      
      const success = await storage.deleteBot(id);
      if (!success) {
        return res.status(404).json({ message: "Bot not found" });
      }

      await storage.createActivity({
        botId: null,
        type: "deleted",
        message: `Bot deleted`
      });

      res.json({ message: "Bot deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete bot" });
    }
  });

  // Get stats
  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await botManager.getSystemStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Get activities
  app.get("/api/activities", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const activities = await storage.getRecentActivities(limit);
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });

  // Get logs
  app.get("/api/logs", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      const botId = req.query.botId ? parseInt(req.query.botId as string) : undefined;
      
      const logs = botId 
        ? await storage.getBotLogs(botId, limit)
        : await storage.getRecentLogs(limit);
      
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch logs" });
    }
  });

  return httpServer;
}
