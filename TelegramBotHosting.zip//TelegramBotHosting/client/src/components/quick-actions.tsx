import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Plus } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Activity } from "@shared/schema";

export default function QuickActions() {
  const { toast } = useToast();
  const [botToken, setBotToken] = useState("");
  const [botName, setBotName] = useState("");

  const { data: activities } = useQuery<Activity[]>({
    queryKey: ["/api/activities"],
    refetchInterval: 30000,
  });

  const { data: stats } = useQuery({
    queryKey: ["/api/stats"],
    refetchInterval: 30000,
  });

  const addBotMutation = useMutation({
    mutationFn: (data: { token: string; name: string }) =>
      apiRequest("POST", "/api/bots", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      setBotToken("");
      setBotName("");
      toast({ title: "Success", description: "Bot added successfully" });
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to add bot", 
        variant: "destructive" 
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!botToken.trim()) {
      toast({ title: "Error", description: "Bot token is required", variant: "destructive" });
      return;
    }
    
    const name = botName.trim() || "Unnamed Bot";
    addBotMutation.mutate({ token: botToken, name });
  };

  function formatRelativeTime(date: Date) {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    
    if (minutes < 1) return "Just now";
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  }

  function getActivityColor(type: string) {
    switch (type) {
      case "started": case "created": return "bg-green-500";
      case "stopped": case "deleted": return "bg-gray-500";
      case "paused": return "bg-yellow-500";
      case "error": return "bg-red-500";
      default: return "bg-blue-500";
    }
  }

  return (
    <>
      {/* Add New Bot Form */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Add Bot</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="botToken">Bot Token</Label>
              <Input
                id="botToken"
                type="text"
                placeholder="1234567890:ABCdefGHIjklMNOpqrsTUVwxyz"
                value={botToken}
                onChange={(e) => setBotToken(e.target.value)}
                className="mt-1"
              />
              <p className="text-xs text-gray-500 mt-1">Get your bot token from @BotFather</p>
            </div>
            <div>
              <Label htmlFor="botName">Bot Name (Optional)</Label>
              <Input
                id="botName"
                type="text"
                placeholder="My Awesome Bot"
                value={botName}
                onChange={(e) => setBotName(e.target.value)}
                className="mt-1"
              />
            </div>
            <Button 
              type="submit" 
              className="w-full" 
              disabled={addBotMutation.isPending}
            >
              <Plus className="w-4 h-4 mr-2" />
              {addBotMutation.isPending ? "Adding..." : "Add & Start Bot"}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* System Status */}
      <Card>
        <CardHeader>
          <CardTitle>System Status</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">API Status</span>
            <Badge className="bg-green-100 text-green-700 hover:bg-green-100">
              <div className="w-1.5 h-1.5 bg-green-500 rounded-full mr-1"></div>
              Operational
            </Badge>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Database</span>
            <Badge className="bg-green-100 text-green-700 hover:bg-green-100">
              <div className="w-1.5 h-1.5 bg-green-500 rounded-full mr-1"></div>
              Healthy
            </Badge>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Webhook Service</span>
            <Badge className="bg-yellow-100 text-yellow-700 hover:bg-yellow-100">
              <div className="w-1.5 h-1.5 bg-yellow-500 rounded-full mr-1"></div>
              Degraded
            </Badge>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">CPU Usage</span>
            <span className="text-sm font-medium text-gray-900">{stats?.cpuUsage || 0}%</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Memory Usage</span>
            <span className="text-sm font-medium text-gray-900">{stats?.memoryUsage || 0}%</span>
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          {!activities || activities.length === 0 ? (
            <div className="text-center py-4">
              <p className="text-gray-500 text-sm">No recent activity</p>
            </div>
          ) : (
            <div className="space-y-3">
              {activities.slice(0, 5).map((activity) => (
                <div key={activity.id} className="flex items-start space-x-3">
                  <div className={`w-2 h-2 ${getActivityColor(activity.type)} rounded-full mt-2`}></div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-gray-900">{activity.message}</p>
                    <p className="text-xs text-gray-500">
                      {formatRelativeTime(new Date(activity.timestamp))}
                    </p>
                  </div>
                </div>
              ))}
              <div className="mt-4 pt-4 border-t border-gray-100">
                <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">
                  View all activity
                </button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </>
  );
}
