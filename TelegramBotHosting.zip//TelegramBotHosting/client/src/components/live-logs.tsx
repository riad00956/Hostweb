import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Download, Play, Pause } from "lucide-react";
import { useWebSocket } from "@/hooks/use-websocket";
import type { Log, Bot } from "@shared/schema";

export default function LiveLogs() {
  const [selectedBotId, setSelectedBotId] = useState<string>("all");
  const [isLive, setIsLive] = useState(true);
  const [liveLogs, setLiveLogs] = useState<Log[]>([]);
  const { lastMessage } = useWebSocket();

  const { data: bots } = useQuery<Bot[]>({
    queryKey: ["/api/bots"],
  });

  const { data: logs, refetch } = useQuery<Log[]>({
    queryKey: ["/api/logs", selectedBotId === "all" ? undefined : selectedBotId],
    queryFn: () => {
      const url = selectedBotId === "all" 
        ? "/api/logs?limit=50"
        : `/api/logs?botId=${selectedBotId}&limit=50`;
      return fetch(url, { credentials: "include" }).then(res => res.json());
    },
  });

  // Handle WebSocket log messages
  useEffect(() => {
    if (lastMessage?.type === "log" && isLive) {
      const newLog = lastMessage.data;
      if (selectedBotId === "all" || selectedBotId === newLog.botId?.toString()) {
        setLiveLogs(prev => [newLog, ...prev.slice(0, 49)]);
      }
    }
  }, [lastMessage, isLive, selectedBotId]);

  // Reset live logs when bot filter changes
  useEffect(() => {
    setLiveLogs([]);
    refetch();
  }, [selectedBotId, refetch]);

  const displayLogs = isLive && liveLogs.length > 0 ? liveLogs : logs || [];

  function getLevelColor(level: string) {
    switch (level) {
      case "error": return "text-red-400";
      case "warn": return "text-yellow-400";
      case "info": return "text-green-400";
      default: return "text-gray-400";
    }
  }

  function getLevelText(level: string) {
    switch (level) {
      case "error": return "[ERROR]";
      case "warn": return "[WARN]";
      case "info": return "[INFO]";
      default: return "[LOG]";
    }
  }

  function getBotName(botId: number | null) {
    if (!botId || !bots) return "System";
    const bot = bots.find(b => b.id === botId);
    return bot ? bot.name : `Bot${botId}`;
  }

  function getBotColor(botId: number | null) {
    if (!botId) return "text-gray-400";
    const colors = ["text-blue-400", "text-purple-400", "text-green-400", "text-red-400", "text-yellow-400"];
    return colors[botId % colors.length];
  }

  function formatTimestamp(date: Date | string) {
    const d = new Date(date);
    return d.toLocaleString("en-US", {
      year: "numeric",
      month: "2-digit", 
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false
    });
  }

  const handleExport = () => {
    const logText = displayLogs.map(log => 
      `[${formatTimestamp(log.timestamp)}] ${getLevelText(log.level)} [${getBotName(log.botId)}] ${log.message}`
    ).join('\n');
    
    const blob = new Blob([logText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bot-logs-${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Live Logs</CardTitle>
        <div className="flex items-center space-x-2">
          <Select value={selectedBotId} onValueChange={setSelectedBotId}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Bots</SelectItem>
              {bots?.map(bot => (
                <SelectItem key={bot.id} value={bot.id.toString()}>
                  {bot.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm" onClick={handleExport}>
            <Download className="w-4 h-4 mr-1" />
            Export
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="bg-gray-900 rounded-lg p-4 font-mono text-sm overflow-x-auto h-80 overflow-y-auto">
          {displayLogs.length === 0 ? (
            <div className="text-gray-400 text-center py-8">
              No logs available
            </div>
          ) : (
            <div className="space-y-1">
              {displayLogs.map((log, index) => (
                <div key={`${log.id || index}-${log.timestamp}`} className="text-gray-300">
                  <span className="text-gray-500">[{formatTimestamp(log.timestamp)}]</span>{" "}
                  <span className={getLevelColor(log.level)}>{getLevelText(log.level)}</span>{" "}
                  <span className={getBotColor(log.botId)}>[{getBotName(log.botId)}]</span>{" "}
                  {log.message}
                </div>
              ))}
            </div>
          )}
        </div>
        <div className="mt-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Button
              variant={isLive ? "default" : "outline"}
              size="sm"
              onClick={() => setIsLive(!isLive)}
              className={isLive ? "bg-green-600 hover:bg-green-700" : ""}
            >
              {isLive ? <Pause className="w-4 h-4 mr-1" /> : <Play className="w-4 h-4 mr-1" />}
              {isLive ? "Live" : "Paused"}
            </Button>
            {isLive && (
              <span className="text-xs text-gray-500">Auto-refreshing</span>
            )}
          </div>
          <div className="flex items-center space-x-2 text-sm text-gray-500">
            <span>Showing last {displayLogs.length} entries</span>
            <button className="text-blue-600 hover:text-blue-700">View all logs</button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
