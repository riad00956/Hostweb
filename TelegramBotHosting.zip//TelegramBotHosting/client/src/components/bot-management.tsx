import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Bot, 
  Plus, 
  BarChart3, 
  FileText, 
  Settings, 
  RotateCcw, 
  Square, 
  Play, 
  Trash2,
  Pause
} from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Bot as BotType } from "@shared/schema";
import { useWebSocket } from "@/hooks/use-websocket";
import { useEffect } from "react";

function formatUptime(seconds: number) {
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  if (days > 0) return `${days}d ${hours}h`;
  if (hours > 0) return `${hours}h`;
  return `${Math.floor(seconds / 60)}m`;
}

function getBotGradient(index: number) {
  const gradients = [
    "from-blue-500 to-purple-600",
    "from-green-500 to-teal-600", 
    "from-red-500 to-pink-600",
    "from-yellow-500 to-orange-600",
    "from-indigo-500 to-blue-600"
  ];
  return gradients[index % gradients.length];
}

function getStatusBadge(status: string) {
  switch (status) {
    case "running":
      return (
        <Badge className="bg-green-100 text-green-700 hover:bg-green-100">
          <div className="w-1.5 h-1.5 bg-green-500 rounded-full mr-1"></div>
          Running
        </Badge>
      );
    case "paused":
      return (
        <Badge className="bg-yellow-100 text-yellow-700 hover:bg-yellow-100">
          <Pause className="w-3 h-3 mr-1" />
          Paused
        </Badge>
      );
    case "error":
      return (
        <Badge className="bg-red-100 text-red-700 hover:bg-red-100">
          <div className="w-1.5 h-1.5 bg-red-500 rounded-full mr-1"></div>
          Error
        </Badge>
      );
    default:
      return (
        <Badge variant="secondary">
          <Square className="w-3 h-3 mr-1" />
          Stopped
        </Badge>
      );
  }
}

export default function BotManagement() {
  const { toast } = useToast();
  const { lastMessage } = useWebSocket();
  
  const { data: bots, isLoading } = useQuery<BotType[]>({
    queryKey: ["/api/bots"],
    refetchInterval: 30000,
  });

  // Handle WebSocket updates
  useEffect(() => {
    if (lastMessage?.type === "bot_status") {
      queryClient.invalidateQueries({ queryKey: ["/api/bots"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
    }
  }, [lastMessage]);

  const startBotMutation = useMutation({
    mutationFn: (botId: number) => apiRequest("POST", `/api/bots/${botId}/start`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots"] });
      toast({ title: "Success", description: "Bot started successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to start bot", variant: "destructive" });
    },
  });

  const stopBotMutation = useMutation({
    mutationFn: (botId: number) => apiRequest("POST", `/api/bots/${botId}/stop`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots"] });
      toast({ title: "Success", description: "Bot stopped successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to stop bot", variant: "destructive" });
    },
  });

  const pauseBotMutation = useMutation({
    mutationFn: (botId: number) => apiRequest("POST", `/api/bots/${botId}/pause`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots"] });
      toast({ title: "Success", description: "Bot paused successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to pause bot", variant: "destructive" });
    },
  });

  const restartBotMutation = useMutation({
    mutationFn: (botId: number) => apiRequest("POST", `/api/bots/${botId}/restart`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots"] });
      toast({ title: "Success", description: "Bot restarted successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to restart bot", variant: "destructive" });
    },
  });

  const deleteBotMutation = useMutation({
    mutationFn: (botId: number) => apiRequest("DELETE", `/api/bots/${botId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots"] });
      toast({ title: "Success", description: "Bot deleted successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete bot", variant: "destructive" });
    },
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Bot Management</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="border border-gray-200 rounded-lg p-4 animate-pulse">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gray-200 rounded-lg"></div>
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-gray-200 rounded w-32"></div>
                    <div className="h-3 bg-gray-200 rounded w-24"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Bot Management</CardTitle>
        <Button size="sm">
          <Plus className="w-4 h-4 mr-2" />
          Add Bot
        </Button>
      </CardHeader>
      <CardContent>
        {!bots || bots.length === 0 ? (
          <div className="text-center py-8">
            <Bot className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">No bots configured yet</p>
            <p className="text-sm text-gray-400 mt-1">Add your first bot to get started</p>
          </div>
        ) : (
          <div className="space-y-4">
            {bots.map((bot, index) => (
              <div
                key={bot.id}
                className={`border rounded-lg p-4 hover:border-gray-300 transition-colors ${
                  bot.status === "error" ? "border-red-200 bg-red-50" : "border-gray-200"
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className={`w-12 h-12 bg-gradient-to-br ${getBotGradient(index)} rounded-lg flex items-center justify-center`}>
                      <Bot className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">{bot.name}</h3>
                      <p className="text-sm text-gray-500">@{bot.username}</p>
                      <div className="flex items-center space-x-4 mt-1">
                        {getStatusBadge(bot.status)}
                        <span className="text-xs text-gray-500">
                          {bot.status === "running" && bot.uptime 
                            ? `Uptime: ${formatUptime(bot.uptime)}`
                            : bot.lastActive 
                              ? `Last active: ${new Date(bot.lastActive).toLocaleString()}`
                              : "Never started"
                          }
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button variant="ghost" size="sm">
                      <BarChart3 className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <FileText className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Settings className="w-4 h-4" />
                    </Button>
                    
                    {bot.status === "running" && (
                      <>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => restartBotMutation.mutate(bot.id)}
                          disabled={restartBotMutation.isPending}
                          className="text-yellow-600 hover:text-yellow-700"
                        >
                          <RotateCcw className="w-4 h-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => pauseBotMutation.mutate(bot.id)}
                          disabled={pauseBotMutation.isPending}
                          className="text-yellow-600 hover:text-yellow-700"
                        >
                          <Pause className="w-4 h-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => stopBotMutation.mutate(bot.id)}
                          disabled={stopBotMutation.isPending}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Square className="w-4 h-4" />
                        </Button>
                      </>
                    )}
                    
                    {bot.status !== "running" && (
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => startBotMutation.mutate(bot.id)}
                        disabled={startBotMutation.isPending}
                        className="text-green-600 hover:text-green-700"
                      >
                        <Play className="w-4 h-4" />
                      </Button>
                    )}
                    
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => deleteBotMutation.mutate(bot.id)}
                      disabled={deleteBotMutation.isPending}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                
                {bot.status === "error" && bot.errorMessage && (
                  <div className="mt-3">
                    <div className="bg-white border border-red-200 rounded-lg p-3">
                      <p className="text-sm text-red-800 font-medium">Connection Error</p>
                      <p className="text-xs text-red-600 mt-1">{bot.errorMessage}</p>
                    </div>
                  </div>
                )}
                
                <div className="mt-4 grid grid-cols-3 gap-4 pt-4 border-t border-gray-100">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-gray-900">{bot.messageCount}</p>
                    <p className="text-xs text-gray-500">Messages Total</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-gray-900">{bot.totalUsers}</p>
                    <p className="text-xs text-gray-500">Total Users</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-gray-900">
                      {bot.responseTime ? `${bot.responseTime}ms` : "--"}
                    </p>
                    <p className="text-xs text-gray-500">Avg Response</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
