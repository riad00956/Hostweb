import { Bot, Navigation2, MessageSquare, Clock, AlertTriangle } from "lucide-react";
import StatsOverview from "@/components/stats-overview";
import BotManagement from "@/components/bot-management";
import QuickActions from "@/components/quick-actions";
import LiveLogs from "@/components/live-logs";

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Bot className="h-8 w-8 text-blue-600" />
                <h1 className="text-xl font-bold text-gray-900">BotHost</h1>
              </div>
              <nav className="hidden md:flex space-x-8">
                <a href="#" className="text-blue-600 border-b-2 border-blue-600 pb-4 px-1 text-sm font-medium">
                  Dashboard
                </a>
                <a href="#" className="text-gray-500 hover:text-gray-700 pb-4 px-1 text-sm font-medium">
                  Analytics
                </a>
                <a href="#" className="text-gray-500 hover:text-gray-700 pb-4 px-1 text-sm font-medium">
                  Logs
                </a>
                <a href="#" className="text-gray-500 hover:text-gray-700 pb-4 px-1 text-sm font-medium">
                  Settings
                </a>
              </nav>
            </div>
            <div className="flex items-center space-x-4">
              <button className="text-gray-500 hover:text-gray-700">
                <AlertTriangle className="h-5 w-5" />
              </button>
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                <span className="text-white text-sm font-medium">U</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Overview */}
        <StatsOverview />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Bot Management */}
          <div className="lg:col-span-2">
            <BotManagement />
          </div>

          {/* Quick Actions */}
          <div className="space-y-8">
            <QuickActions />
          </div>
        </div>

        {/* Live Logs */}
        <div className="mt-8">
          <LiveLogs />
        </div>
      </div>
    </div>
  );
}
